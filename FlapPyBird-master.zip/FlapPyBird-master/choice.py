print('What Do you Want to Run .NewsReader Or Flappy Py Game Enter 1 For Flappy Game or 2 for NewsReader ')
input_a = input()
input_a = int(input_a) 
if(input_a == 1):
     print('Flappy game')
elif (input_a == 2):
     print('NewsReader')
else: 
    print('Wrong Input')    
