import json  
import requests 

def speak(str):
    from win32com.client import Dispatch
    speak= Dispatch("SAPI.Spvoice")
    speak.Speak(str)

if __name__ == "__main__":
    speak("Lets begin the news of today")
    url="http://newsapi.org/v2/top-headlines?country=in&apiKey=ebaf6c6e0dd948f8b0bfc1c7afd88d7a"
    news= requests.get(url).text
    
    news=json.loads(news)
    article=(news['articles'])
    for i in article:
        print(i["title"]) 
        speak(i["title"]) 
        
        
        speak("next news is")

    else:
        speak("thanks for listening")    
